def plain():
    pass