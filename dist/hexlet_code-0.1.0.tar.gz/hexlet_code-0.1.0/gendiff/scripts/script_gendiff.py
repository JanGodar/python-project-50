from gendiff.gendiff_file import get_gendiff


def main():
    get_gendiff()

if __name__ == '__main__':
    main()