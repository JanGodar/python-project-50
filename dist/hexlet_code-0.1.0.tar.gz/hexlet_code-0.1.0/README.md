### Hexlet tests and linter status:
[![Actions Status](https://github.com/JanGodar/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/JanGodar/python-project-50/actions)

<a href="https://codeclimate.com/github/JanGodar/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/245538c9e0f746272089/maintainability" /></a>